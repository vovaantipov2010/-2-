﻿# /un/

<p style="color:red"><i>Incoming message</i>:</p> Друзья, много времени прошло с того момента, как я начал работу над FDL. Три года, если быть точным. И последней версией оказалась 6.5. Я внёс последнюю строчку кода с этим коммитом и решил, что мне пора двигаться дальше, поэтому я архивирую репозиторий, никаких изменений вноситься больше не будет. Я его оставлю для себя на память. <br>
Пирожковую я передал доверенному лицу, которое сможет продолжать вести её. <br>
Тред в скором времени утонет. Создайте новый, если нужно. <br>
Весь код я оставляю открытым: любой может посмотреть его и модифицировать под свои нужды. На его полное понимание может уйти не один день, но оно того стоит. Я гарантирую это. <br>
Используйте форк от этого репозитория в качестве шапки. Изменения в FDL тоже вносите в форк.<br>
И убедительная просьба: не пишите мне по поводу этого всего. Игнорирую и блокирую. <br>
Ну, вот и всё, сайонара. Люблю всех.

---

## **_2016 г._**

...

<details>
<summary>⚛️ <b>[Технические]</b></summary>

- [Математика. Подготовка к ЕГЭ. Часть С](https://rutracker.org/forum/viewtopic.php?t=5257235)

- [Физика. Подготовка к ЕГЭ. Часть С](https://rutracker.org/forum/viewtopic.php?t=5257249)

- [Информатика. Экспресс-подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5257220)

- [Алгебра. 10 класс](https://rutracker.org/forum/viewtopic.php?t=5427254)

- [Геометрия. 10 класс](https://rutracker.org/forum/viewtopic.php?t=5429370)

</details>
<br>
<details>
<summary>✊ <b>[Гуманитарные]</b></summary>

- [Русский Язык. Подготовка к ЕГЭ. Сочинение](https://rutracker.org/forum/viewtopic.php?t=5257263)

- [Экспресс-курс. Учи английский легко.](https://cloud.mail.ru/public/6og2/YZeFbTwYT/)

</details>
<br>

**_Части B Математики и Физики находятся здесь:_**

https://mega.nz/#!BFNV3Q7b!kioo4rQuzS5l7GyGpXJyGhlgPlnSQ2c15DYMsuOi8kw

---

## **_2017 г._**

...

<details>
<summary>⚛️ <b>[Технические]</b></summary>

- [Подготовка к ОГЭ. Физика](https://rutracker.org/forum/viewtopic.php?t=5446633)

- [Подготовка к олимпиадам. Математика. 9 класс](https://rutracker.org/forum/viewtopic.php?t=5446632)

- [Экспресс-подготовка к ОГЭ. Физика](https://rutracker.org/forum/viewtopic.php?t=5446621)

- [Подготовка к ОГЭ. Математика](https://rutracker.org/forum/viewtopic.php?t=5446635)

- [Экспресс-подготовка к ОГЭ. Математика](https://rutracker.org/forum/viewtopic.php?t=5446623)

- [Углубленный курс. Алгебра](https://rutracker.org/forum/viewtopic.php?t=5446627)

- [Углубленный курс. Геометрия](https://rutracker.org/forum/viewtopic.php?t=5446626)

- [Подготовка к олимпиадам "Физтех" по математике](https://rutracker.org/forum/viewtopic.php?t=5418196)

- [Подготовка к олимпиадам "Физтех" по физике](https://rutracker.org/forum/viewtopic.php?t=5441240)

- [Подготовка к олимпиадам по математике](https://rutracker.org/forum/viewtopic.php?t=5418108)

- [Подготовка к олимпиадам по физике](https://rutracker.org/forum/viewtopic.php?t=5442687)

- [Программирование (9-11 классы). Подготовка к олимпиадам, базовый уровень](https://rutracker.org/forum/viewtopic.php?t=5444437)

- [Программирование (9-11 классы). Подготовка к олимпиадам, продвинутый уровень](https://rutracker.org/forum/viewtopic.php?t=5417314)

- [Математика. Подготовка к ЕГЭ / Часть С](https://rutracker.org/forum/viewtopic.php?t=5417886)

- [Математика. Экспресс-подготовка к ЕГЭ / Часть С](https://rutracker.org/forum/viewtopic.php?t=5444510)

- [Математика. Экспресс-подготовка к ЕГЭ / Часть B](https://rutracker.org/forum/viewtopic.php?t=5444960)

- [Физика. Экспресс-подготовка к ЕГЭ / Часть С](https://rutracker.org/forum/viewtopic.php?t=5444953)

- [Физика. Экспресс-подготовка к ЕГЭ / Часть B](https://rutracker.org/forum/viewtopic.php?t=5444954)

- [Информатика. Подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5417807)

- [Изучение языков С и С++ / Язык С++](https://rutracker.org/forum/viewtopic.php?t=5417828)

- [Web-программирование](https://rutracker.org/forum/viewtopic.php?t=5418437)

- [Программирование на языке Python](https://rutracker.org/forum/viewtopic.php?t=5444423)

</details>
<br>
<details>
<summary>✊ <b>[Гуманитарные]</b></summary>

- [Подготовка к ОГЭ. Обществознание](https://rutracker.org/forum/viewtopic.php?t=5446634)

- [Подготовка к олимпиадам. Обществознание](https://rutracker.org/forum/viewtopic.php?t=5446630)

- [Русский язык. Подготовка к ЕГЭ. Часть 1](https://rutracker.org/forum/viewtopic.php?t=5444409)

- [Русский язык. Экспресс-подготовка к ЕГЭ. Часть 1](https://rutracker.org/forum/viewtopic.php?t=5444957)

- [Русский язык. Сочинение. Экспресс-подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5444449)

- [Английский язык. Подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5444419)

- [Английский язык. Экспресс-подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5444434)

- [Стань сильнее. Pre-Intermediate (A2-B1)](https://rutracker.org/forum/viewtopic.php?t=5444412)

- [Обществознание. Экспресс-подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5444307)

- [Обществознание. Подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5444303)

- [Обществознание. Подготовка к олимпиадам](https://mega.nz/#F!Vv4AmCpS!ClUpGarpD8yXyrx1MEoeLQ)

- [История. Подготовка к ЕГЭ](https://mega.nz/#F!NyxmnDzT!x9kTW9VsdY28oCT4KvNBBA)

</details>
<br>
<details>
<summary>🔬 <b>[Естественно-научные]</b></summary>

- [Биология. Подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5438805)

- [Биология. Экспресс-подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5444414)

- [Биология. Подготовка к олимпиадам](https://rutracker.org/forum/viewtopic.php?t=5445005)

- [Химия. Подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5441118)

- [Химия. Подоготовка к олимпиадам](https://rutracker.org/forum/viewtopic.php?t=5444426)

- [Химия. Экспресс-подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5444500)

</details>
<br>
<details>
<summary>💡 <b>[Другое]</b></summary>

- [Словесность. Работа с информацией](https://rutracker.org/forum/viewtopic.php?t=5446832)

- -

</details>
<br>

---

## **_2018 г._**

...

<details>
<summary>⚛️ <b>[Технические]</b></summary>

- [Подготовка к ОГЭ. Математика. 9 класс](https://cloud.mail.ru/public/95XE/g3e1XZCrE)

- Подготовка к олимпиадам. Математика. 9 класс:

  - [Видео](https://mega.nz/#F!br4g1CRb!Yi_hw2wmK4BPe7fXCQmA4Q)
  - [Д/З](https://yadi.sk/d/dNIoDTyW3ajwh7)

- [Подготовка к ОГЭ. Физика. 9 класс](https://mega.nz/#F!qfxHUA7I!vV1DaKK0-tUVxo4ocBBA3A)

- [Геометрия. Углубленный уровень. 10 класс](https://yadi.sk/d/-Rv0BQU-3aYjgM)

- Подготовка к ЕГЭ. Математика. 10 класс:

  - [Видео](https://mega.nz/#F!vagE3aCa!i20C7ttAZavCPhe4SAfqeg)
  - [Д/З](https://yadi.sk/d/Ij3LuPWs3aUjTn)

- Подготовка к ЕГЭ. Математика. C-часть:

  - [Презентации](https://mega.nz/#F!HXgwTLzQ!5VgTKJvGKh_3VxfNctx9HQ)
  - [Видео](https://mega.nz/#F!Ln40BSpa!ciyrGIRZhD6vsn-x0EMUUA)
  - [Д/З](https://yadi.sk/d/ll2e8ATk3a3xPB)

- Экспресс-подготовка к ЕГЭ. Математика. В-часть.

- Экспресс-подготовка к ЕГЭ. Математика. С-часть.

- Физика. Подготовка к ЕГЭ. С-часть:

  - [Презентации](https://mega.nz/#F!bOp2FbrJ!eR7EbmgcBX82xEVJZpY4QA)
  - [Видео](https://mega.nz/#F!vrhllCKB!Mo5ebF8JJGsULfJgu3f9Lg)
  - [Д/З](https://mega.nz/#F!nWJAHQDI!mjP9Z_C7LuSTgkZW0Nm-0w)

- [Физика. Экспресс-подготовка к ЕГЭ. С-часть](https://yadi.sk/d/JCp76aCp3aVxHd)

- [Физика. Экспресс-подготовка к ЕГЭ. В-часть](https://yadi.sk/d/jlvSYm5t3aVhqQ)

- [Математика. Подготовка к олимпиаде Физтех](https://yadi.sk/d/PFwGVYZn3aWX9x)

- Курс подготовки к олимпиадам «Ломоносов», ОММО, ПВГ по математике:

  - [Теория](https://cloud.mail.ru/public/26aB/YRvzhyJe1)
  - [Видео](https://mega.nz/#F!ezxWSCaL!3XPe3dRspzkoL74uVz_tLg)

- Физика. Подготовка к олимпиаде Физтех:

  - [Видео](https://mega.nz/#F!XWBAHQLZ!bFdDHnqx1uUq0h7gLxdfxw)
  - [Д/З](https://yadi.sk/d/h7kaU9Mj3a5fGa)

- Физика. Подготовка к олимпиадам. 10 класс:

  - [Видео](https://mega.nz/#F!nvhniQxD!5p07SQGsfjOGsZ0T-A2u1w)
  - [Д/З](https://yadi.sk/d/BzMMJBXl3aNgiv)

- [Физика. Подготовка к олимпиадам. 9 класс](https://yadi.sk/d/DNN651RR3aC5Qa)

- [Физика. Подготовка к олимпиадам. 8 класс](https://yadi.sk/d/eum01uh1tzdlcw)

- Информатика. Подготовка к ЕГЭ.

- [Информатика. Подготовка к олимпиадам](https://mega.nz/#F!zS431KpL!9J9wwxYsf49aw5Jbd-Py4Q)

- Мини-курс по математике "Векторный метод в пространстве"

- Мини-курс по математике "Логарифм и экспонента"

- [Мини-курс по математике "Теория вероятностей"](https://cloud.mail.ru/public/99iR/ydhDPcVQm)

- [Мини-курс по математике "Сравнения по модулю"](https://cloud.mail.ru/public/4qPd/N65dNQCNP)

- [Интенсивный курс по математике "Задачи с параметрами на ЕГЭ"](https://yadi.sk/d/Ban_jjxM3WbeQY)

- [Интенсивный курс по математике "Задачи по теории чисел на ЕГЭ"](https://yadi.sk/d/LfusFOrL3WbkxS)

- Мини-курс по физике "Магнетизм и электромагнитная индукция":

  - [Видео](https://yadi.sk/d/qTfLE88L3WYDwV)
  - [Д/З](https://mega.nz/#F!Di5HWB5C!6qxfCkgSms6ulB-EzThz7w)

- Мини-курс по физике "Метод потенциалов":

  - [Видео](https://cloud.mail.ru/public/9ksB/xhg2QYGsx)
  - [Д/З](https://yadi.sk/d/2pezugnf3aXrUR)

- [Мини-курс по физике "Олимпиадная механика"](https://cloud.mail.ru/public/2Eu5/zkaih3SBm)

- [Мини-курс по физике "Эксперементальный практикум по гидростатике"](https://cloud.mail.ru/public/F8Pi/TuJj8LMxm)

- [Мини-курс по физике "Эксперементальный практикум по тепловым и электрическим явлениям"](https://cloud.mail.ru/public/5vvV/qWLiAi5kx)

- Мини-курс по физике "Разные подходы к решению задач по гидростатике":

  - [Видео](https://cloud.mail.ru/public/JZCp/p3eiaBapy)
  - [Д/З](https://yadi.sk/d/oWVeHXOp3aXrUh)

- [Курс по программированию в среде "Swift Playgrounds"](https://yadi.sk/d/JMhZwtQO3Uf9aU)

- Язык Python

- [Язык С++](https://mega.nz/#F!f3ZlwYIJ!5Mc6LPZv4Z-eHkXcqZJ4Yw)

</details>
<br>
<details>
<summary>✊ <b>[Гуманитарные]</b></summary>

- [Подготовка к ОГЭ. Русский язык. 9 класс](https://cloud.mail.ru/public/Lrgj/hEMedDyVS)

- [Подготовка к олимпиадам. Русский язык. 8-11 класс](https://mega.nz/#F!DWhgXaLC!gxoZCsPOOK-0dI6kwiK_ug)

- [Курс подготовки к написанию сочинений и изложений на ОГЭ и ГВЭ 9 класс](https://cloud.mail.ru/public/GfZf/EKm5vTgbJ)

- Английский язык. Подготовка к ЕГЭ.

- [Русский язык. Экспресс-курс по подготовке к сочинению.](https://yadi.sk/d/P1Dv8v2V3WurE3)

- Русский язык. Подготовка к декабрьскому сочинению.

- [Русский язык. 1 часть.](https://cloud.mail.ru/public/151p/52H17pYrV)

- Русский язык. 1 часть - Экспресс.

- Литература. 11 класс:

  - [Видео 1](https://cloud.mail.ru/public/fW2v/tmUfA3VjJ)
  - [Видео 2](https://cloud.mail.ru/public/DVTH/vwQo4AP2P)

- [История. Подготовка к ЕГЭ.](https://mega.nz/#F!zzxk1C7C!EI3o8bquUt8cmYUOjxHHZQ)

- [История. Подготовка к ОГЭ.](https://cloud.mail.ru/public/Esxr/wePkYv1XB)

- [Подготовка к олимпиадам по праву](https://yadi.sk/d/j5coXPRF3X2dwV)

- [Обществознание. Подготовка к ЕГЭ.](https://drive.google.com/drive/u/4/folders/1LQL1AYK5R0ZmqCUagDFPq8UWz2knyh1E)

- [Обществознание. Подготовка к ОГЭ.](https://cloud.mail.ru/public/EB4p/2sQ3aiwiw)

- Обществознание. Подготовка к олимпиадам:

  - [Видео](https://yadi.sk/d/ZvZKfGJC3YtGQi)
  - [Материалы](https://yadi.sk/d/5O-mW7i63ajfhX)

</details>
<br>
<details>
<summary>🔬 <b>[Естественно-научные]</b></summary>

- [Химия. Подготовка к ЕГЭ](https://yadi.sk/d/YdnVWd7H3aWR4C)

- [Химия. Экспресс-подготовка к ЕГЭ](https://yadi.sk/d/kiXwNckX3ZBKeC)

- [Биология. Подготовка к ЕГЭ](https://yadi.sk/d/3rtloxF43aVTnp)

</details>
<br>
<details>
<summary>💡 <b>[Другое]</b></summary>

- [Финансовая грамотность и современные платежные технологии](https://yadi.sk/d/gcrg9MWI3Wveax)

- [Шахматы - Начальный уровень](https://cloud.mail.ru/public/2z81/zTmxF1w9t)

- [Серия курсов "Эмоциональный интеллект" - "Научиться учиться" и "Навыки будущего"](https://cloud.mail.ru/public/ESjC/XxmDqZGsj)

- [Основы информатики и программирования](https://cloud.mail.ru/public/DQUN/ZV3K6kVQ7)

- [Эффективное мышление на основе ТРИЗ. 7-8 класс](https://cloud.mail.ru/public/AS7U/SsBGoVsJx)

</details>
<br>

---

## **_2019 г._**

...

<details>
<summary>⚛️ <b>[Технические]</b></summary>

- [Подготовка к олимпиаде "Физтех" по математике](https://mega.nz/#F!LO5ThIyJ!O2bAf058daQ_z57fXxhpyQ)

- [Подготовка к олимпиадам «Ломоносов», ОММО, ПВГ](https://yadi.sk/d/QOIk2Kqovc0yTA)

- [Подготовка к региональному этапу Всероссийской олимпиады по математике](https://yadi.sk/d/AxRwHbEx9gJnqg)

- [Подготовка к ДВИ в МГУ по математике](https://mega.nz/#F!upoWxSpD!k1oTK1U0p6t4wLZFFS6naQ)

- [Математика. Подготовка к ЕГЭ. Часть С](https://mega.nz/#F!IZ9CDarJ!ol_8oe2BQRSWz6L3_ps8IA)

- [Математика. Подготовка к ЕГЭ. Часть Б](https://rutracker.org/forum/viewtopic.php?p=77546191)

- [Мини-курс по математике "Векторный метод в пространстве"](https://yadi.sk/d/VpO8uoXWqzfwVg)

- [Мини-курс по математике "Логарифм и экспонента"](https://yadi.sk/d/ZjwU9gwjjsRP3g)

- [Мини-курс по математике "Сравнения по модулю"](https://mega.nz/#F!wWhAzS7J!yFx74dbv66CZGLWkTiFgjQ)

- [Мини-курс по математике "Свойства пределов последовательности"](https://mega.nz/#F!tSonXY6J!GE75bbyXw7cF0P4y1yJTdg)

- [Интенсивный курс по математике "Задачи с параметрами на ЕГЭ"](https://yadi.sk/d/KBOGGfuw4EGfkA)

- [Интенсивный курс по математике "Задачи по теории чисел на ЕГЭ"](https://yadi.sk/d/p5EdqMRD8xLZBA)

- [Подготовка к олимпиадам "Физтех", "Росатом", "Ломоносов" по физике](https://mega.nz/#F!phNGGCSA!bOnNCKQqNFRuuCC6C2ceRQ)

- [Мини-курс по физике "Магнетизм и электромагнитная индукция"](https://mega.nz/#F!ckkhTIRY!D0WREaqE2jCCk8op0BfDfw)

- [Физика. Классическая астрономия](https://mega.nz/#F!dWZ3ESAJ!7AvKeNfd-dDPH9b0LwEihw)

- [Физика. Геометрическая оптика](https://mega.nz/#F!W7QUDayS!YgJiM2rU45TVpokrZTLeKQ)

- [Физика. Методы расчёта разветвлённых цепей](https://mega.nz/#F!D3QGQCKS!RCcL2gdroOETqR8CYqW-rA)

- [Физика. Тепловые явления](https://mega.nz/#F!SmQmmCjD!knIpGZMIDEXgS5rVmDUxsg)

- [Мини-курс "Экспериментальная физика"](https://mega.nz/#F!TrBk0I6R!K2DtfwTMUeVj-wddZZx-VA)

- [Физика. Кинематические связи в задачах](https://mega.nz/#F!anB2xIaZ!BwslrBueo0utACSnGXL8ZA)

- [Физика. Подготовка к ЕГЭ. Часть С](https://yadi.sk/d/xjco_AKXdTx99A)

- [Физика. Подготовка к ЕГЭ. Часть Б](https://yadi.sk/d/1oARnGevJVwAew)

- [Информатика. Экспресс-подготовка к ЕГЭ](https://t.me/joinchat/AAAAAEZLIl-XWzOC5SIpEw)

- [Информатика. Подготовка к ЕГЭ](https://mega.nz/#F!M0sWlSyK!x2o0BcBymqJ9yEF54WnIZw)

- [Программирование. Подготовка к окружному этапу олимпиады](https://yadi.sk/d/INsWH9BHTFapXQ)

- [Программирование. Подготовка к региональному этапу олимпиады](https://yadi.sk/d/MK4m1lvIM3jmIw)

- [Программирование. Курс подготовки к олимпиадам, продвинутый уровень](https://yadi.sk/d/_1HXesluVTZp9Q)

- [Языки С/С++](https://mega.nz/#F!qjIwhQ6T!vwjiDExbiiDLjTO6vsCULA)

- [Язык Python для начинающих](https://t.me/joinchat/AAAAAFFbpvBSQ0NRqvYK3g)

- [Язык Python для продолжающих](https://mega.nz/#F!uiQGUY5Y!uJaqRZ2C6IRzOYIzXyUfjQ)

- [Информатика за пределами ЕГЭ](https://mega.nz/#F!PvIQHYDD!UrgW5M6--ttg-vnnhrNbDQ)

</details>
<br>
<details>
<summary>✊ <b>[Гуманитарные]</b></summary>

- [Два выпускных сочинения - декабрьское и ЕГЭ](https://mega.nz/#F!a3xXCQKB!ScDw8eROMoq5tGW9-tyZzA)

- [Русский язык. Тест](https://mega.nz/#F!S3gTXKQL!18qfHt1NtecA3mLxfjK0Sg)

- [Подготовка к олимпиадам и международным экзаменам по английскому языку](https://mega.nz/#F!S3oCSIhC!AXXh5rl-Tt5vvZTlQ0rYhA)

- [История. Базовый уровень](https://mega.nz/#F!T7xxUKbD!Nvd5DWo2z2bXReMqmFnXDg)

- [История. Подготовка к ЕГЭ](https://mega.nz/#F!WmpTEYhS!0JNn1OGL0fq48qtWCiE5RA)

- [Обществознание. Базовый уровень](https://mega.nz/#F!wHBE3YQY!FocKT3Lt8sLUIBgACGgw3w)

- [Обществознание. Подготовка к ЕГЭ](https://mega.nz/#F!wDw3HaAZ!XtxUVJDg_eVFFBfxFqSyHQ)

- [Литература. Базовый уровень](https://mega.nz/#F!cKwGwSLB!1zdADwaRsRaqEWdkZNfJug)

- [Литература без границ. Читательский дайвинг клуб](https://mega.nz/#F!FOAXhKjR!Jn9ki9KNEDYErfN4O7Wmng)

</details>
<br>
<details>
<summary>🔬 <b>[Естественно-научные]</b></summary>

- [Химия. Базовый уровень](https://mega.nz/#F!DvZAwSaJ!-wkNQlzKPGuSeF5Yop9ogw)

- [Химия. Подготовка к ЕГЭ](https://rutracker.org/forum/viewtopic.php?t=5746100)

- [Практикум. Органическая химия](https://mega.nz/#F!23oEWSSD!kGIBxWfen7Rjt7YHrrz5OQ)

- [Практикум. Неорганическая химия](https://mega.nz/#F!PzgRUCbC!lQ_bIvGZGlDTaHXZhIYNEg)

- [Практикум. Общая химия](https://mega.nz/#F!bvBTQKpY!cq3yAgjspLMS-0GakdjUhw)

- [Практикум. Олимпиадная химия](https://mega.nz/#F!znYVGSzD!bIKrPKNjDpYIOOaPq1B0CA)

- [Биология. Базовый уровень](https://mega.nz/#F!n7AWTQrA!YYPfc_l10RaJ_Ir5liuD0w)

- [Биология. Подготовка к ЕГЭ](https://mega.nz/#F!z3whlCDI!7WllZIhXidu9yEeFnkXa_g)

- [Ботаника](https://mega.nz/#F!iuhxXYib!n6otON815nAJ0FAAXP6GuA)

</details>
<br>
<details>
<summary>💡 <b>[Другое]</b></summary>

- [Шахматы. Продвинутый уровень](https://mega.nz/#F!H6I0hY7Z!5an9b-wzH_-llTWqSZY7PA)

- [Эмоциональный интеллект - Навыки XXI века](https://drive.google.com/drive/folders/1z3RItBOKTBVg8Dglv2ek5f53PGGFX-2P?usp=sharing)

</details>
<br>

---

**Дополнительно**

_(2017) Недостающая теория для:_

- Подготовка к олимпиадам по математике (11 класс)
- Подготовка к олимпиаде "Физтех" по математике
- Подготовка к олимпиадам по программированию. Продвинутый уровень (9-11 класс)
- Подготовка к олимпиадам по программированию. Базовый уровень (7-9 класс)
- Язык С++
- Физика (Часть В и С)

https://mega.nz/#F!T9pR3STQ!pjIy_jvZOMvg9ucrMENKSw

...

---

**Каналы**

- [_47-я Пирожковая (бывает не только Фоксфорд)_](https://t.me/joinchat/AAAAAFAGr87npHU8ras3zQ)

- [_Сливы со сливы (умскул)_](https://t.me/shokavosliv)

---

**Теория для мобильных устройств**

- [_Android_](https://play.google.com/store/apps/details?id=ru.foxford.foxfordtextbook)

- [_iOS_](https://itunes.apple.com/us/app/foksford.ucebnik/id930911649?l=ru&ls=1&mt=8)

---

**Основные ударения для ЕГЭ по русскому можно отработать здесь:**

https://russianpy.marisehayashi.repl.run/

---

**Учебные материалы**

- _ВМК, Поляков, Ткаучук и прочее:_

  https://mega.nz/#F!Ei4GmBCL!eKqBEOF9fmCwnOnuSELowQ

- _Платина разного рода:_

  https://github.com/tanookki/FizMatInf

---

[**Извлечение данных**](https://github.com/limitedeternity/foxford_courses/tree/master/foxford_downloader/)

---

**ОГРОМНАЯ ПРОСЬБА: НЕ УХОДИТЕ С РАЗДАЧИ - ВНЕСИТЕ СВОЙ ПОСИЛЬНЫЙ ВКЛАД В ОБЩЕЕ ДЕЛО.**

_Есть что-то, что вы хотите раздать? Хотите починить нерабочие ссылки и можете это сделать? Или дополнить? Редактируйте и делайте pull request._

_Курсы предоставлены в ознакомительных целях. Обновленная версия курсов будет читаться на сайте foxford.ru с сентября, преимуществами покупки актуальной версии являются доступ к домашним заданиям и возможность задать вопросы лектору в онлайн-режиме._

**Благодарности:**

- `limitedeternity (Zamazka03)` : Скрипт, координация команды, поддержка. Маг программного кода.

- `Stanley Kowalski` : Оказание поддержки, тестирование, идеи для скрипта. Страж программного кода.

- `Paravozik_Lesha` : Титан трудоспособности, перезаливка/заливка на рутрекер; рыцарь Света, охраняющий раздачи и участвовавший абсолютно во всех сражениях (сливах). Предпочитает меч снайперской винтовке. Щедро раздал необходимые курсы, что имелись на его аккаунте. Свидетель Первой Версии.

- `TmLev (soloLev)` : Основа последнего слива, именуемого Крупнейшим. Любезно предоставил аккаунт с практически всеми необходимыми курсами.
  Помог извлечь историю и обществознание. Паладин Света.

- `Yakui_The_Maid` : Анонимный союзник сил Света. Предоставил стандартные курсы биологии, химии и физики части С.

- `Г-жа Н` : Ещё один союзник. Основатель канала, загрузка почти всех курсов.

- `Pavel Павлик` : 90% курсов 2019 года

- И многие другие.
