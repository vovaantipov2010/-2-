# How to contribute
---------------

### **Make sure that all requirements are satisfied:**

* You are using the latest version of script.

* You have the latest Node.js installed.

**ONLY THEN YOU CAN SUBMIT ANY BUG REPORTS**
